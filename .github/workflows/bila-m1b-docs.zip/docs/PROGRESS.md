# BILA progress log

Last updated: 2026-11-08 (M1 complete; unpack workflow ready for its first run).

## Deadline

Development ends **2026-11-14 23:59 UTC** (judging from 2026-11-16, results by 2026-11-18). Internal target: submit by the end of 2026-11-13. 2026-11-14 is buffer only.

## Milestones

| # | Target (UTC) | Scope and exit criteria | Status |
| --- | --- | --- | --- |
| M1 | Nov 6 (done Nov 7) | Foundation. Repository and CI in place; `cargo test` passes, wasm builds with cargo-near, and the brand check passes, all in CI. | **Done**: CI run #1 green (commit `81394af`, 2m 37s) |
| M2 | Nov 8 (compressed from Nov 7-8) | Enforcement core in `bila-core`: agent registry (register, pause, resume, revoke), policies, restricted treasury (deposit, allocate, withdraw unreserved), UTC period math, atomic reservations. Mandatory tests 1-10, 13, 14. | Not started |
| M3 | Nov 9 | Settlement: transfer by promise, `#[private]` callback, idempotency, failure release, receipts. Sandbox integration tests incl. mandatory tests 11-12. First testnet deploy. | Not started |
| M4 | Nov 10 | MCP server and policy engine: authenticated, scoped tools; connect Claude. | Not started |
| M5 | Nov 10-11 | Dashboard: Overview, Agents, Transactions, Treasury, Security and settings. | Not started |
| M6 | Nov 12 | End-to-end testnet rehearsal and security pass. | Not started |
| M7 | Nov 13 | README for the AI screener, architecture diagram, demo video, X post, repo public, submit. | Not started |

**Schedule note (2026-11-08):** M1 finished on Nov 7, a day late, so M2 is compressed into Nov 8. Proposed: if M3 slips past Nov 9, the dashboard shrinks to Overview, Agents and Transactions.

**Cut line if we slip** (in this order): no Postgres (chain-first, ADR-007); read-only Security screen; fewer dashboard charts. Never cut: atomic reservation, failure release, the 14 mandatory tests, README accuracy.

## Verification ledger

What has actually been run, and where. Nothing is marked verified unless it was executed and the result observed.

| Item | How | Result |
| --- | --- | --- |
| Logo copy is byte-identical to the upload | `cmp` and SHA-256 in the Claude sandbox, 2026-11-06 | Verified |
| `scripts/check-brand.sh` passes, and fails when the logo is altered | Run in the sandbox, positive and negative test | Verified |
| `devcontainer.json` is valid JSON; `Cargo.toml` and `rust-toolchain.toml` parse as TOML; shell scripts pass `bash -n`; `ci.yml` parses as YAML | Parsed in the sandbox | Verified (syntax only) |
| Palette contrast ratios in `docs/BRAND.md` | Computed with the WCAG formula | Verified |
| `cargo test` passes | Blocking step of CI run #1 (green), 2026-11-07. The step log itself was not read. | Verified in CI |
| Contract skeleton compiles; wasm builds with cargo-near | Blocking steps of CI run #1 | Verified in CI |
| CI run is green | Actions page screenshot from the owner: run #1, commit `81394af`, 2m 37s | Verified |
| Format and lint (advisory step) | Result not read yet | **Unknown** |
| `post-create.sh` works end to end; dev container builds | Not run: the Codespace was created before the dev container was added, and CI does not use it | **Not verified** |
| Unpack workflow (`.github/workflows/unpack.yml`) | Script logic tested in the sandbox against local git repos (normal bundle, unsafe paths, no zip, workflow-only zip). The GitHub-specific parts (token permissions, starting CI) have not run yet | **Partly verified** |

Facts checked against sources on 2026-11-05 (re-check before relying on them):

- near-sdk 5.30.0 released 2026-10-27; its README declares minimum Rust 1.95: https://docs.rs/near-sdk and https://github.com/near/near-sdk-rs
- cargo-near installer command and `cargo near build non-reproducible-wasm --no-abi`: near-sdk README (above)
- near.org public RPC endpoints are deprecated; use a listed provider: https://docs.near.org/api/rpc/providers
- Hackathon rules and form fields: https://nearhackathon.com/HACKATHON.md
- Codespaces free plan: 120 core-hours and 15 GB-month per month for personal accounts: https://docs.github.com/en/billing/concepts/product-billing/github-codespaces

## Hackathon submission checklist

From HACKATHON.md (fetched 2026-11-05; re-read the live file before submitting, rules may change):

- [ ] Repository public before 2026-11-14 23:59 UTC. Judges cannot open a private repository.
- [ ] `LICENSE` present (done: MIT).
- [ ] README written for a machine reader first: what it is, the problem, and accurate "do X, see Y" steps. No marketing. Claude Code and Codex screen every project before the human judges.
- [ ] README lists libraries, templates and AI-generated code (started under "Built with").
- [ ] Demo **video** if the demo is local-only (screenshots are not enough when judges cannot open the demo). A hosted demo is a plus; keep it up to 2026-11-18, ideally 2026-11-25.
- [ ] Public X post: says the project was built at NEAR HACKATHON, tags @NEARProtocol and #NEARHackathon, has the video or screenshots attached. The owner posts it.
- [ ] Decide whether to keep `.github/workflows/unpack.yml` in the final commit. It is a development helper.
- [ ] Submission form: project name, team lead, email, team size, tracks (`security`, `agents`), a **mainnet** NEAR account for any prize payout, repository link, demo post link, description of 20 to 2,000 characters. The owner confirms the exact payload before it is sent.

## Owner actions (manual, cannot be done by the assistant)

- Upload each bundle zip on github.com (see "How updates reach the repo"). The repository and CI exist (M1 done).
- Create a testnet dev account with `cargo near create-dev-account` and approve wallet connections (M3 onward). Never paste keys or seed phrases into chat.
- Create a mainnet NEAR account for the prize payout (before M7).
- Record the demo video, publish the X post, make the repository public, and submit the form (M7).

## Decisions needed from the owner

1. Confirm ADR-007 (chain-first, no Postgres in the critical path) before M5.
2. Send an original vector or large PNG of the logo if one exists (see `docs/BRAND.md`).

## How updates reach the repo

The owner works from an iPhone, where typing and pasting in a terminal are unreliable, so code travels as a zip:

1. The assistant sends a zip with no top-level folder.
2. The owner opens `https://github.com/<owner>/<repo>/upload/main`, picks the zip and taps Commit changes. The zip must land in the repository root.
3. `.github/workflows/unpack.yml` unpacks it, deletes every zip at the root, commits the result and starts CI on the new commit.

Limits: only zips added by the triggering push are unpacked. GitHub's built-in token cannot change files under `.github/workflows`, so workflow files are skipped with a warning and are sent separately for upload into `.github/workflows` by hand. A bundle cannot delete files other than zips.

## Blockers

- The assistant's sandbox has no Rust toolchain and no network, so compiling, testing and deploying happen in CI (or a Codespace). Until a result is relayed or visible in CI, it is not verified.
- Typing and pasting in the iPhone terminal are unreliable, so updates are delivered as zips (see "How updates reach the repo").

## Next task

Confirm the unpack workflow works on its first real bundle (the docs update), then start M2: agent registry, policies, restricted treasury, UTC period math and atomic reservations in `bila-core`.
